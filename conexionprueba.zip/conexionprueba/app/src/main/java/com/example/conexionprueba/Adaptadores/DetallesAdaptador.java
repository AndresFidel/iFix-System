package com.example.conexionprueba.Adaptadores;

public class DetallesAdaptador {
}
