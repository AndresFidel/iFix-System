package com.example.conexionprueba;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class verDetalles extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_detalles);
    }
}
