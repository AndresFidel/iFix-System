package com.example.conexionprueba;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

//Clase login
public class login extends AppCompatActivity {

    //Objeto barra de carga
    private ProgressBar progressBarAnimation;
    private ObjectAnimator progressAnimator;

    //Declaracion de las variables.
    EditText usuarioTxt, passTxt;
    Button loginBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //Inicializando barra de carga
        init();
        progressAnimator.setDuration(4000);

       //Delay para mostrar la barra de carga y despues lanzar el metodo iniciar sesion
        findViewById(R.id.loginBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressAnimator.start();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        iniciarSesion();
                    }
                },3000);
            }
        });

        //Proceso de finalizacion de barra de carga
        progressAnimator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                progressBarAnimation.setVisibility(View.GONE); //Quitar la barra de carga
            }
        });


        usuarioTxt=(EditText) findViewById(R.id.usuarioTxt); //Buscando el ID para guardar nombre del usuario.
        passTxt=(EditText) findViewById(R.id.passTxt); //Buscando el ID para guardar la contraseña del usuario.
        loginBtn=(Button)findViewById(R.id.loginBtn); //Buscando el ID del boton Iniciar sesion.

        verificarActividad(); //Verificar si el usuario no ha cerrado sesión.
    }

    //Localizando la barra de carga e inicializando sus valores
    private void init(){
        progressBarAnimation= findViewById(R.id.ProgressBar);
        progressAnimator=ObjectAnimator.ofInt(progressBarAnimation,"progress",0,100);
    }

    //Funcion para realizar la conexion con SQL server
    public Connection conexionBD(){
        Connection conexion=null;
        try{
            StrictMode.ThreadPolicy policy=new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            Class.forName("net.sourceforge.jtds.jdbc.Driver").newInstance();
            conexion= DriverManager.getConnection("jdbc:jtds:sqlserver://ifix.database.windows.net;databaseName=ifixdb;user=raulballeza;password=ifixdb_ads_68;");

        }catch(Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
        }
        return conexion; //Retornando la conexión.
    }

    //Funcion para el inicio de sesión
    public void iniciarSesion(){
        try{

            String usuario=usuarioTxt.getText().toString();
            String pass=passTxt.getText().toString();
            boolean bandera=true;

            //Verificando campos vacios.
            if(usuario.isEmpty())
            {
                usuarioTxt.setError("Usuario no ingresado.");
                progressBarAnimation.setVisibility(View.VISIBLE);
                bandera=false;
            }
            if(pass.isEmpty()){
                passTxt.setError("Contraseña no ingresada.");
                progressBarAnimation.setVisibility(View.VISIBLE);
                bandera=false;
            }


            //Bandera para permitir el acceso de login.
            if(bandera==true) {
                //Realizando busqueda del usuario mediante una consulta.
                Statement stm = conexionBD().createStatement();
                ResultSet rs = stm.executeQuery("EXEC buscarUsuario @p_usuario='" + usuarioTxt.getText().toString() + "'");

                //Comprobando usuario existenete
                if (rs.next()) {
                    String passVer=passTxt.getText().toString(); //Guardando valor del textview en una variable
                    String passReal=rs.getString(4); //Guardando el valor de la columna cuatro de la tabla cliente a la variable
                    if(passReal.equals(passVer)) {
                        Toast.makeText(getApplicationContext(), "Accediendo al usuario " + usuarioTxt.getText(), Toast.LENGTH_SHORT).show();
                        PreparedStatement pst = conexionBD().prepareStatement("EXEC iniciarSesion @p_usuario='" + usuarioTxt.getText() + "', @p_pass='" + passTxt.getText() + "'");
                        pst.executeUpdate();
                        //Dirigiendonos a la siguiente activity
                        Intent siguiente = new Intent(login.this, mostrarDatos.class);
                        startActivity(siguiente);
                        finish();
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "El usuario no existe.", Toast.LENGTH_SHORT).show();
                        progressBarAnimation.setVisibility(View.VISIBLE);
                    }
                }
            }
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    } //Fin metodo iniciarSesion


    //Metodo para verificar si el usuario aun sigue logeado.
    public void verificarActividad(){
        try{
            Statement stm=conexionBD().createStatement();
            ResultSet rs= stm.executeQuery("EXEC usuarioActivo");

            if(rs.next()){
                Intent siguiente=new Intent(login.this,mostrarDatos.class);
                startActivity(siguiente);
                finish();
            }
            else
            {
                Toast.makeText(getApplicationContext(),"Bienvenido a la APP iFix.",Toast.LENGTH_SHORT).show();
            }
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }//Fin metodo verificarActividad

} //Fin clase login
