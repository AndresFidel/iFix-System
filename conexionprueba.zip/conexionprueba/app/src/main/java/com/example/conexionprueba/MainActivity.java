package com.example.conexionprueba;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.conexionprueba.Modales.MostrarAyuda;

import org.w3c.dom.Text;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MainActivity extends AppCompatActivity {

    //Declarando variables
    TextView usuarioTxt;
    Button salirBtn;
    ImageView imgAyuda;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        salirBtn=(Button)findViewById(R.id.salirBtn); //Boton para cerrar sesión
        usuarioTxt=(TextView)findViewById(R.id.usuarioTxt); //Nombre del usuario iniciado
        imgAyuda=(ImageView)findViewById(R.id.imgAyuda); //Buscando la imagen para mostrar ayuda.
        mostrarUsuario();

        //Evento del boton para cerrar sesión.
        salirBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cerrarSesion();
            }
        });

        imgAyuda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog();
            }
        });

    }

    //Invocando la funcion para abrir un modal de ayuda.
    public void openDialog(){
        MostrarAyuda exampleDialog=new MostrarAyuda();
        exampleDialog.show(getSupportFragmentManager(),"example dialog");
    }

    //Funcion para realizar la conexion con SQL remoto.
    public Connection conexionBD(){
        Connection conexion=null;
        try{
            StrictMode.ThreadPolicy policy=new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            Class.forName("net.sourceforge.jtds.jdbc.Driver").newInstance();
            //Direccion de la base de datos remotamente.
            conexion= DriverManager.getConnection("jdbc:jtds:sqlserver://ifix.database.windows.net;databaseName=ifixdb;user=raulballeza;password=ifixdb_ads_68;");

        }catch(Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT).show();

        }
        return conexion;
    }

//Funcion para mostrar el usuario logueado.
    public void mostrarUsuario(){
        try{
            Statement stm=conexionBD().createStatement();
            ResultSet rs= stm.executeQuery("SELECT * FROM sesion");

            if(rs.next()){
                usuarioTxt.setText(rs.getString(1));
            }
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }

    //Funcion para cerrar sesion
    public void cerrarSesion(){
        try{
            PreparedStatement pst=conexionBD().prepareStatement("DELETE sesion");
            pst.executeUpdate();


            Toast.makeText(getApplicationContext(),"El usuario cerrado sesión.",Toast.LENGTH_SHORT).show();
            //Dirigiendonos a la activity de login.
            Intent inicio=new Intent(MainActivity.this,login.class);
            startActivity(inicio);
        }
        catch(Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }

}
