package com.example.conexionprueba.Constructores;

public class tipoDetalle {
}
